
const checkbox = document.querySelector('#switch')
const rootElement = document.documentElement


const lightTheme = {
    '--bgColor': '#ffffff',
    '--font2': '#454545'
}

const darkTheme = {
    '--bgColor': '#151515',
    '--font2': 'white'
}

checkbox.addEventListener('change', function() {
    const isChecked = checkbox.checked
    isChecked ? changetheme(darkTheme) : changetheme(lightTheme)
})

function changetheme(theme) {
    for(let a in theme){
        changeProperty(a, theme[a])
    }
}

function changeProperty(property, value) {
    rootElement.style.setProperty(property, value)
}







var span = document.querySelector('.tempo')

var play = document.querySelector('.fa-play')
var pause = document.querySelector('.fa-pause')

var btnStart = document.querySelector('.start')
var btnStop = document.querySelector('.stop')

var hh = 0
var mm = 0
var ss = 0

var tempo = 15
var cron

btnStop.disabled = true


function start() {

   if(play.classList.contains('fa-play')){
        play.classList.remove('fa-play')
        play.classList.add('fa-pause')

        cron = setInterval(() => { timer() }, tempo)

        btnStop.disabled = false
   }
   else {
        play.classList.remove('fa-pause')
        play.classList.add('fa-play')

        clearInterval(cron)

        btnStop.disabled = false
   }

}

function stop() {

    clearInterval(cron)
    span.innerHTML = "00:00.00"

    hh = 0
    mm = 0
    ss = 0

    if(play.classList.contains('fa-play')){
        play.classList.remove('fa-play')
        play.classList.add('fa-pause')

        btnStop.disabled = true
    }
    if(play.classList.contains('fa-pause')){
        play.classList.remove('fa-pause')
        play.classList.add('fa-play')

        btnStop.disabled = true
    }

}

function timer() {
    ss++

    if(ss == 60){
        ss = 0
        mm++

        if(mm == 60){
            mm = 0
            hh++
        }
    }

    var format = (hh < 10 ? '0' + hh : hh) + ':' + (mm < 10 ? '0' + mm : mm) + '.' + (ss < 10 ? '0' + ss : ss);
    span.innerHTML = format;
}




const handleClickOutside = (event) => {
    let overlay = document.getElementById("overlay");
    let modal = document.getElementById("modal");
    if (!modal.contains(event.target)) {
        modal.style.display = 'none';
        overlay.style.display = 'none';
        document.removeEventListener('click', handleClickOutside, false);
    }
}

const openModal = () => {
    let overlay = document.getElementById("overlay");
    let modal = document.getElementById("modal");
    overlay.style.display = 'flex'
    modal.style.display = 'flex'
    setTimeout(() => { document.addEventListener('click', handleClickOutside, false) }, 200);
}